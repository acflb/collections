## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=markyin0707/typora-activation&type=Date)](https://star-history.com/#markyin0707/typora-activation&Date)

## Typora激活

### 一、前言

Typora从免费版本到收费版，对于囊中羞涩的学生党不方便使用。并且购买的收费版也只是只能购买一个大版本，不能永久一次性购买，这一点确实有点不够良心。所以在没有经济独立的学生党可以使用一下该版本的Typora激活，但是希望有条件支持正版的工作党🔞🈲️请支持正版，毕竟开发公司开发软件也很辛苦。

还有一种激活最新版1.8.10的方案[链接](https://blog.csdn.net/qq_37636739/article/details/136338284), 但是我觉得还挺麻烦, 不如更换winmm.dll来的方便。

### 二、激活步骤

1. 先安装 typora-setup-x64-1.3.8.exe ，记下安装路径
2. 将 winmm.dll 替换到安装路径下含有typora.exe的文件夹中
3. 重启typora，即可激活
5. 有条件请支持正版

### 三、注意事项

1. 请下载对应版本文件，***不要更新typora***，毕竟typora更新变化不大，老版本功能和新版本基本上没有很大的差距。不能保证后续版本该方法任然有效。
2. star之后可以watch一下，如果有新的激活方案，会马上更新

---

## Typora activation

### 1、preface

Typora from the free version to the paid version, it is not easy for the cash-strapped student party to use. And the paid version can only be purchased in a large version, not a permanent one-time purchase, which is a bit bad. So students who are not financially independent can use this version of Typora activation. However, if you have a job  🔞 🈲️ and want to support the legal version, please support the legal version. After all, it is very hard for development companies to develop software.

There is also a solution to activate the latest version 1.8.10 [link](https://blog.csdn.net/qq_37636739/article/details/136338284)

### 2、The activation step

1. First install typora-setup-x64-1.3.8.exe ，and remember the installation path.
2. Replace winmm.dll with a folder containing typora.exe in the installation path.
3. Restart typora to activate it.
5. If possible, please support the genuine version.

### 3、Matters needing attention

1. Download the corresponding version file，***Do Not Update Typora***.After all, typora update changes little, the old version and the new version of functions are basically no big gap. There is no guarantee that this method will work in subsequent versions.
2. You can watch it after star. If there is a new activation plan, it will be updated immediately.
