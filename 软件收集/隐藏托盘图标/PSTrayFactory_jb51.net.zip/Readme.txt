PS Tray Factory v3.2 (shareware version)
Copyright (C) 1999-2010 PS Soft Lab
All Rights Reserved

PS Tray Factory allows you:
-  to move low-activity icons from a system tray into menu,
-  to change the order of icons in the system tray (sort tray),
-  to restore system tray icons after Explorer.exe crash,
-  to replace the original tray icons with your own icons,
-  to quickly access hidden icons,
-  to hide seldom used icons,
-  to protect tray menu with password,
-  to minimize any application to system tray.
.

===============================
NEW IN THIS VERSION:
===============================
- new look for classic system tray menu (notification area popup window like in Windows 7),
- several improvements for better compatibility with Windows 7.


===============================
 INSTALLATION  PS Tray Factory 
===============================
 pstrayf.exe will install the program PS Tray Factory.


===============================
 SYSTEM REQUIREMENTS
===============================
      
- Windows 95-98, Me, NT4, 2K, XP, Vista, Windows 7 (32/64 bit);
- 486-based PC (Pentium recommended);
- 32 MB RAM (recommended);
- VGA monitor with 1000's or millions of color display;
- 2 MB hard disk space;
- mouse;
- administrative privileges under Win NT/2K/XP/Vista.

===============================
 UNINSTALLATION
===============================

 To Uninstall:

 Use the standard uninstall feature "Add/Remove Programs"
 in the Control Panel.

===============================
 CONTACT
===============================
 For questions, problems or comments:

 email:
 support@pssoftlab.com
 website: http://www.pssoftlab.com

 
 

