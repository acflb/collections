需要使用2.0.0+版本的工具箱才能使用该预设包!
适用于Windows 10、11 (工具箱支持的系统版本)
预设包发布页:
https://winmoes.com/theme/16158.html

工具箱:
https://winmoes.com/tools/12948.html

插图来自:
https://twitter.com/TEIGI_3
https://shiroseijyo-anime.com/
https://www.bilibili.com/bangumi/play/ss45504


主题预设包仅供个人桌面使用 请勿用于任何其他或商业用途 由此导致的后果我们概不负责